/**
 * @file course.h
 * @author Lavan Sivappiragasam (sivappil@mcmaster.ca)
 * @brief Header file that contains course typedef and defines functions used in course.c.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief Uses typedef and struct to create course variable that is used through other files.
  * 
  */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief This function enrolls a student in the course by allocating memory for a student typdef variable to enroll in the  course typedef variable.
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief This function prints the information about the course given by the pointer to the course variable. The specific information that is printed is student names, codes and total number of students in the class.
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 */
void print_course(Course *course);

/**
 * @brief This function analyzes the marks of the students and returns the student with the top mark.
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 * @return Student* Returns the student typedef variable that pertains to the student with the highest mark in the class.
 */
Student *top_student(Course* course);

/**
 * @brief This function analyzes the class marks to determine the number of students with a passing grade(50% or greater).
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 * @param total_passing Pointer for the total_passing variable that points to the storage of memory for information about passing students(50% or greater).
 * @return Student* Returns the dynamic array that pertains to the students with passing grades(50% or greater).
 */
Student *passing(Course* course, int *total_passing);


