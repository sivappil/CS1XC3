/**
 * @file main.c
 * @author Lavan Sivappiragasam (sivappil@mcmaster.ca)
 * @brief Program generates a class filled with students to demonstrate the use of course and student libraries.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Calls functions from student.c and course.c to demonstrate the use of these libraries.
 * 
 * @return int 
 */
int main()
{
  //Seed the random number generator
  srand((unsigned) time(NULL));

  //Create a dynamic array MATH101 from the typedef Course. Use calloc to make the size of the array 1.
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enroll 20 randomly generated students into the course MATH101 by calling enroll_student from the file course.c and generate_random_student from the file student.c with the use of a for loop set to 20 times to create a class of 20 students. Fill the dynamic array with these 20 students.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Create a typedef student variable to assign to the top student of MATH101. Print out this top student.
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Create a dynamic array passing_students using the typedef student variable to allocate the memory of the students with 50% or greater in MATH101. Call the passing function from course.c. Using a for loop to go through each student in the class, if a student's grade is passing, add them to the dynamic array.
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}