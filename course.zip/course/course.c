/**
 * @file course.c
 * @author Lavan Sivappiragasam (sivappil@mcmaster.ca)
 * @brief File contains multiple functions that analyze students in a class and output different analytics of the class.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief This function enrolls a student in the course by allocating memory for a student typdef variable to enroll in the  course typedef variable.
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //If the course size is 1, then use calloc to allocate memory for the class size.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //When the course size is greater than 1, use realloc to reallocate memory to increase the class size dynamic array.
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This function prints the information about the course given by the pointer to the course variable. The specific information that is printed is student names, codes and total number of students in the class.
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //Repeat the for loop for the number of students in the class and print out the above information for each student. 
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function analyzes the marks of the students and returns the student with the top mark.
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 * @return Student* Returns the student typedef variable that pertains to the student with the highest mark in the class.
 */

Student* top_student(Course* course)
{
  //If there are no students in the class then there is no top student.
  if (course->total_students == 0) return NULL;
 
  //Assume the first student has the top mark
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  //Go through the mark of each student one-by-one and if the currently analyzed student has a higher mark than the student with the highest mark, replace the student with the previous highest mark with the currently analyzed student. This student will now have the new highest mark. Return the student with the highest mark when finished cycling through all students.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function analyzes the class marks to determine the number of students with a passing grade(50% or greater).
 * 
 * @param course Pointer for the course variable that points to the storage of memory for the course information.
 * @param total_passing Pointer for the total_passing variable that points to the storage of memory for information about passing students(50% or greater).
 * @return Student* Returns the dynamic array that pertains to the students with passing grades(50% or greater).
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //For each student with a grade that is 50% or greater, increase the counter that counts passing students by 1.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Allocate memory to store the passing students to an array.
  passing = calloc(count, sizeof(Student));

  //For every student with a grade that is 50% or greater, add them to the array that stores the students with a passing grade.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}