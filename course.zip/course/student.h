/**
 * @file student.h
 * @author Lavan Sivappiragasam (sivappil@mcmaster.ca)
 * @brief Header file that contains student typedef and defines functions used in student.c.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Uses typedef and struct to create student variable that is used through other files.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief This function adds a student's grade into the dynamic array of the student's information.
 * 
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 * @param grade Double value of a student's grade in the class that will be added.
 */
void add_grade(Student *student, double grade);

/**
 * @brief This function adds up the grades of a student and divides by the number of grades to return the student's average.
 * 
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 * @return double variable of the average of a student's grades.
 */
double average(Student *student);

/**
 * @brief This function prints the information pertaining to pointer variable of typedef student variable. So, it prints a student's name, ID, grades, and average.
 * 
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 */
void print_student(Student *student);

/**
 * @brief The student typedef function randomly generates information for a student that can be used to add to a course.
 * 
 * @param grades Int value of a student's grade in the class.
 * @return Student* Returns the student typedef variable that pertains to the information of a student.
 */
Student* generate_random_student(int grades); 
