/**
 * @file student.c
 * @author Lavan Sivappiragasam (sivappil@mcmaster.ca)
 * @brief This program contains functions that analyze student information to output many different tasks.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This function adds a student's grade into the dynamic array of the student's information.
 * 
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 * @param grade Double value of a student's grade in the class that will be added.
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //If the student only has 1 grade, then use calloc to allocate memory for the grade.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  //When the number of grades is greater than 1, use realloc to reallocate memory to increase the size of the dynamic array to incorporate more grades.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This function adds up the grades of a student and divides by the number of grades to return the student's average.
 * 
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 * @return double variable of the average of a student's grades.
 */
double average(Student* student)
{
  //If there are no grades for a student then there is no average for the student.
  if (student->num_grades == 0) return 0;

  //Using a for loop, add up all the grades of a student. Divide the sum by the number of grades the student has.
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief This function prints the information pertaining to pointer variable of typedef student variable. So, it prints a student's name, ID, grades, and average.
 * 
 * @param student Pointer for the student variable that points to the storage of memory for the student information.
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  //Using a for loop, loop through the grades for a student in the dynamic array and print each grade.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief The student typedef function randomly generates information for a student that can be used to add to a course.
 * 
 * @param grades Int value of a student's grade in the class.
 * @return Student* Returns the student typedef variable that pertains to the information of a student.
 */
Student* generate_random_student(int grades)
{
  //Possible first and last names for randomly generated students.
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  //Allocate memory to store a randomly generated student to a dynamic array of size 1.
  Student *new_student = calloc(1, sizeof(Student));

  //Assign a first and last name to each student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Using a for loop, randomly generate an ID of 10 digits using ASCII characters
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //Using a for loop, create a random set of grades for a student.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}